<!DOCTYPE html>
<html lang="en">
<head>
    <title> laboratorio 1.7 </title>
</head>
<body>
    <?php
    $x = 24;
    $pi = 3.1416;
    $animal = "conejo";
    $saludo = "Hola Caracola";
    echo $x, "<br>", $pi, "<br>", $animal, "<br>", $saludo;
    ?>
</body>
</html>