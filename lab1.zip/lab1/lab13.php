<!DOCTYPE html>
<html lang="en">
<head>
    <title> laboratorio 1.3 </title>
</head>
<body>
    <center>
        <?php
        echo phpinfo();
        ?>
    </center>
</body>
</html>