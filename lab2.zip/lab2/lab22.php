<?php
require("noexiste.php");
echo ("Hola, El script siguio!");
?>