<!DOCTYPE html>
<html lang="en">
<head>
    <title> laboratorio 2.3 </title>
</head>
<body>
    <center>
        <?php
            print ("<UL>\n");
            $i=1;
            while ($i <= 5)
            {
                print ("<LI>Elementos $i</LI>\n");
                $i++;
            }
            print ("</UL>\n");
        ?>
    </center>
</body>
</html>