<?php
include 'class_lib.php';

$numero = $_REQUEST['num'] ?? 0;