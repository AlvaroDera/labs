<?php
class miotraclase {
    public function __construct() {
        echo "Mi segunda clase ha sido agregada!!! <br>";
    }
}
?>