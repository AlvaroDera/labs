<?php
class miclase {
    public function __construct() {
        echo "Mi Clase ha sido agregada!!! <br>";
    }
}
?>